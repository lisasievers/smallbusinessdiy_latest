<div class="alert alert-error">
	<button type="button" class="close fui-cross"></button>
	<h4>{{ $data['header'] }}</h4>
	<div>{{ $data['content'] }}</div>
</div>