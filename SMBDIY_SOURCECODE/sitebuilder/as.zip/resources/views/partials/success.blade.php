<div class="alert alert-success">
	<button type="button" class="close fui-cross"></button>
	<h4>{{ $data['header'] }}</h4>
	<div>{{ $data['content'] }}</div>
	{{-- print_r($data) --}}
</div>