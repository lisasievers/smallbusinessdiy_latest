<!DOCTYPE html>
<html class="" lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
	<h2>New user informations</h2>	
	Name: name<br>
	Email: email
</body>
</html>