@extends ('layouts.dashboard')

@section('section')
<div class="col-sm-12">
             Domain purchase wizard from google
       <aside>https://developers.google.com/domains/widget/v1/get-started</aside> 
</div>
@stop
