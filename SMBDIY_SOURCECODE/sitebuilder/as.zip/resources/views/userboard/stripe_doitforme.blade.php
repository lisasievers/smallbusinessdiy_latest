@extends ('layouts.dashboard')

@section('section')
<div class="col-sm-12 ">

        @include('layouts.partials.stripe_form_doitforme') 
</div>

@stop
