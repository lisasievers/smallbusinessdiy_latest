
<span class="badge">{{ $value }}</span>
