<!DOCTYPE html>
<html class="" lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
Dear Team,<br/><br/>

The following payment received in our Stripe account.<br/><br/>

Payment ID: {{$payid}}<br/>

Payment Amount ($): {{$amount}}<br/>

Payment Date : {{$date}}<br/>

Payment against Site : {{$site}}<br/>

Payment User: {{$name}}<br/>

Payment from email : {{$email}}<br/>

Payment status : Success<br/>
	
</body>
</html>