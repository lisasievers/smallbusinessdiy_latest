<!DOCTYPE html>
<html class="" lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
Dear {{$name}},<br/><br/>

Thank you for your Sitebuilder payment. Find below the details:<br/><br/>

Payment ID: {{$payid}}<br/>

Payment Amount ($): {{$amount}}<br/>

Payment Date : {{$date}}<br/>

Payment against Site : {{$site}}<br/>

Payment status : Success<br/>
	
</body>
</html>