<!DOCTYPE html>
<html class="" lang="en">
<head>
<meta charset="utf-8">
</head>
<body>
	<h3>A new user signed up with your SMBDIY</h3>	
	Name: {{$name}}<br>
	Email: {{$email}}
</body>
</html>