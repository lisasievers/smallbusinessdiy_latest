<footer class="site-footer">
    <div class="text-right">
      {{$cdata[3]}}
    </div>
</footer>
