<div class="header-bottom">
    {{--@include('layouts.partials.sidenav')--}}
    @include('layouts.partials.nav.menu-horizontal')
</div>