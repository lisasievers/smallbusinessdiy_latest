<div class="sidebar-left @if($type == 'icon') sidebar-large-icons @endif" id="mobile-nav">
    <div class="sidebar-body scroll-pane">
        @include('layouts.partials.nav.menu-sidebar')
    </div>
</div>

