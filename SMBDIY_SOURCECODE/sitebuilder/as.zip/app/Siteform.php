<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Siteform extends Model
{
    //
}
