<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Web_common_info extends Model
{
   protected $table = "web_common_info";
}
