<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Site_check_report extends Model
{
   protected $table = "site_check_report";
}
